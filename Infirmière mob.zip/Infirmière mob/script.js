// تسجيل المستخدم
const registrationForm = document.getElementById("registrationForm");
registrationForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const userType = document.getElementById("userType").value;
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    alert(`تم تسجيل ${userType === "nurse" ? "ممرض" : "مريض"}: ${name}`);
});

// عرض الخريطة
function initMap() {
    const mapDiv = document.getElementById("map");
    const map = new google.maps.Map(mapDiv, {
        center: { lat: 24.7136, lng: 46.6753 },
        zoom: 10,
    });

    // إضافة ممرضين كمثال
    const nurses = [
        { name: "Ahmed", location: { lat: 24.7136, lng: 46.6753 } },
        { name: "Sara", location: { lat: 24.7743, lng: 46.7386 } },
    ];

    nurses.forEach((nurse) => {
        const marker = new google.maps.Marker({
            position: nurse.location,
            map: map,
            title: nurse.name,
        });

        marker.addListener("click", () => {
            alert(`تواصل مع الممرض: ${nurse.name}`);
        });
    });
}

// استدعاء Google Maps API
document.addEventListener("DOMContentLoaded", () => {
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap`;
    script.async = true;
    document.body.appendChild(script);
});

// الدردشة
const chatForm = document.getElementById("chatForm");
const messages = document.getElementById("messages");

chatForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const message = document.getElementById("messageInput").value;
    const messageDiv = document.createElement("div");
    messageDiv.textContent = `أنت: ${message}`;
    messages.appendChild(messageDiv);
    document.getElementById("messageInput").value = "";
});